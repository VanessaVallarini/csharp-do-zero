using System;

public class Veiculo{
    public int velMax;
    public int rodas;
    private bool ligado;

    public void ligar(){
        ligado=true;
    }

    public void desligar(){
        ligado=false;
    }

    public string getLigado(){
        if(ligado){
            return "Sim";
        }else{
            return "Não";
        }
    }
}