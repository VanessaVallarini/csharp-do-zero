﻿using System;

namespace Aula34_Heranca
{
    class Program
    {
        static void Main(string[] args)
        {
            Carro c1 = new Carro("Fusca", "vermelho");

            Console.WriteLine("Velocidade:.{0}", c1.velMax);
            Console.WriteLine("Rodas:......{0}", c1.rodas);
            Console.WriteLine("Ligado?:....{0}", c1.getLigado());
            Console.WriteLine("Nome:.......{0}", c1.nome);
            Console.WriteLine("Cor:....... {0}", c1.cor);

        }
    }
}
