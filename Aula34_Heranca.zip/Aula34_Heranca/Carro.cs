using System;
//Classe derivada da classe Veiculo
public class Carro:Veiculo{
    public string nome;
    public string cor;
    public Carro(string nome, string cor){
        desligar();
        rodas=4;
        velMax=120;
        this.nome=nome;
        this.cor=cor;
    }


}