﻿using System;
using System.Collections.Generic;

namespace Aula58_Colecao_Queue_Fila
{
    class Program
    {
        static void Main(string[] args)
        {
            //usando um método para criar um array e em seguida adicionar a queue
            //string[] v = {"carro", "navio", "aviao"};
            //Queue<string> veiculos = new Queue<string>(v);
            
            //Criando uma fila
            Queue<string> veiculos = new Queue<string>();

            //adicionando elementos no final da fila
            veiculos.Enqueue("Carro");
            veiculos.Enqueue("Moto");
            veiculos.Enqueue("Navio");
            veiculos.Enqueue("Avião");

            //verificando a quantidade de elementos na fila
            Console.WriteLine("Qtd elementos na fila: {0}", veiculos.Count);
            Console.WriteLine("------------------------------------------");

            //verificando se existe um elemento dentro da fila
            string v = "Avião";
            if(veiculos.Contains(v)){
                Console.WriteLine("O elemento {0} existe na lista!", v);
            }else{
                Console.WriteLine("O elemento {0} NÃO existe na lista!", v);
            }
            Console.WriteLine("------------------------------------------");

            //retorna o elemento e eliminar esse elemento do início da fila
            Console.WriteLine("Retornando e removendo o primeiro veículo: {0}", veiculos.Dequeue());
            Console.WriteLine("Qtd elementos na fila: {0}", veiculos.Count);
            Console.WriteLine("------------------------------------------");

            //retorna o elemento do início da fila
            Console.WriteLine("Retornando o primeiro veículo: {0}", veiculos.Peek());
            Console.WriteLine("Qtd elementos na fila: {0}", veiculos.Count);
            Console.WriteLine("------------------------------------------");

            //retornando todos os elementos da minha fila
            foreach(string v2 in veiculos){
                Console.WriteLine("Elementos da fila veículo: {0}", v2);
            }
            //OBS: NÃO É POSSÍVEL APLICAR INDEXAÇÃO, EX: veiculos[2]
            Console.WriteLine("Qtd elementos na fila: {0}", veiculos.Count);
            Console.WriteLine("------------------------------------------");

            //limpando a fila
            veiculos.Clear();
            Console.WriteLine("A fila foi limpa!");
            Console.WriteLine("Qtd elementos na fila: {0}", veiculos.Count);
            Console.WriteLine("------------------------------------------");

        }
    }
}
