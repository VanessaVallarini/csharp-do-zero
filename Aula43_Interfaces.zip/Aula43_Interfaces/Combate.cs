using System;

public interface Combate{
    public void disparar();
}