﻿using System;

namespace Aula43_Interfaces
{
    class Program
    {
        static void Main(string[] args)
        {
            Carro c1 = new Carro();
        }
    }
}
