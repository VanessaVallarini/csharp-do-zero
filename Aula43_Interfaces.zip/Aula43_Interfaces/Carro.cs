using System;

public class Carro : Veiculo, Combate{
    public bool ligado;
    private int municao;
    public Carro(){}

    public void ligar(){
        this.ligado=true;
    }
    public void desligar(){
        this.ligado=false;
    }
    public void info(){}
    
    public void disparar(){
        this.municao=100;
    }
}