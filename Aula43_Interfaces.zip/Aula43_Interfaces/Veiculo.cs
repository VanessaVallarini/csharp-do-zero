using System;

public interface Veiculo{

    public void ligar();
    public void desligar();
    public void info();
}