﻿using System;

namespace Aula15_SWITCHcase
{
    class Program
    {
        static void Main(string[] args)
        {
            //executa um bloco de comandos conforme o valor de uma expressão é  
            //correspondente a uma constante
            //Ideal quando trabalhamos com opções de escolha

            int tempo=0;
            char escolha;

            Console.WriteLine("BH a Vitoria/ES\nEscolha o transporte:");
            Console.WriteLine("(a) Avião\n(c) Carro\n(o) Ônibus)");

            escolha=char.Parse(Console.ReadLine());

            switch(escolha)
            {
                case 'a':
                case 'A':
                    tempo=50;
                    break;
                case 'c':
                case 'C':
                    tempo=480;
                    break;
                case 'o':
                case 'O':
                    tempo=660;
                    break;
                default:
                    tempo=-1; 
                    break;
            }

            if(tempo < 0)
            {
                Console.WriteLine("Transporte indisponível.");
            }else{
                Console.WriteLine("Tempo para o transporte escolhido: {0} minutos", tempo);
            }
        }
    }
}
