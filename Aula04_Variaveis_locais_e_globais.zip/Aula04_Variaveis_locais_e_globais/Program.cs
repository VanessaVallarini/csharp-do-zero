﻿using System;

namespace Aula04
{
    class Program
    {
        static int num1=10;
        //variável global
        static void Main(string[] args)
        {
            int num2=0;
            //variável local

            Console.WriteLine(num1);

        }
    }
}
