﻿using System;

namespace Aula53_Try_Catch_Finally
{
    class Program
    {
        static void Main(string[] args)
        {
            int n1=0, n2=0, res=0;
            n1=10;
            n2=0;
            //Erro ao dividirmos por 0:
            //Unhandled exception. System.DivideByZeroException: Attempted to divide by zero.
            
            try{//bloco que executa as operações
                res=n1/n2;
                Console.WriteLine("{0}/{1} = {2}", n1, n2, res);
                //Gerando uma exceção 
                //assim, mesmo que a divisão ocorra o bloco catch é executado
                //e ao invés de aparecer o DivideByZeroException
                //a mensagem da exceção será "ERRO CRIADO"
                throw new Exception("ERRO CRIADO");
            }catch(Exception e){//bloco que trata as exceções
                Console.WriteLine("ERRO: {0}", e.Message);
                Console.WriteLine("Tipo da Exceção: {0}", e.GetType());
            }finally{//vai ser executado independente se ocorrer a exceção ou não
                 Console.WriteLine("Fim do programa.");
            }

            Console.WriteLine();
            Console.WriteLine("CALCULANDO AREA");
            float area=0;
            try
            {
                area=Area.Quadrado(0, 5F);
                Console.WriteLine("Area do quadrado: {0}", area);
            }
            catch (Exception e)
            {
                Console.WriteLine("ERRO: {0}", e.Message);
            }finally{
                 Console.WriteLine("Fim do programa.");
            }
        }
    }
}
