﻿using System;

namespace Aula24_Metodos
{
    class Program
    {
        static void Main(string[] args)
        {
            //Métodos: conjuntos de instruções
            //bloco de instrução que pode ser chamado a qualquer momento dentro do programa
            //Podemos usar com parâmetros de entrada 
            //Podemos usar métodos que retornam valores
            //Por essa classe main ser static os métodos que vamos usar devem ser statics
            int valor1, valor2, r;

            Console.WriteLine("Método estático sem entrada de valor");
            ola();
            Console.WriteLine("------------------------------------");

            Console.WriteLine("Método estático com entrada de valor");
            Console.Write("Digite o primeiro valor: ");
            valor1=Convert.ToInt32(Console.ReadLine());
            Console.Write("Digite o segundo valor: ");
            valor2=Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("------------------------------------");
            
            Console.WriteLine("Método estático com entrada de valor");
            soma(valor1,valor2);
            Console.WriteLine("----------------------------------------");

            Console.WriteLine("Método estático com entrada e saída de valor");
            r = soma2(valor1,valor2);
            Console.WriteLine("Soma de {0} e {1} é: {2}",valor1,valor2,r);
            Console.WriteLine("----------------------------------------");
        }

        //método tipo void: não retorna nada
        //os nomes dos métodos devem ser curtos e remeter o que o método faz
        static void ola(){
            Console.WriteLine("Ola");
        }

        static void soma(int n1, int n2){
            int soma=n1+n2;
            Console.WriteLine("Soma de {0} e {1} é: {2}", n1,n2,soma);
        }

        static int soma2(int n1, int n2){
            int soma=n1+n2;
            return soma;
        }


    }
}
