﻿using System;

namespace Aula10_Enum
{
    enum diasSemana{Domingo, Segunda, Terca, Quarta, Quinta, Sexta, Sabado};
    class Program
    {
        static void Main(string[] args)
        {
            //Permite criarmos um tipo próprio ou valores pré definidos
            //Cada elemento possui sua posição no índice, ou seja:
            //Domingo: 0; Segunda: 1....
            diasSemana d = diasSemana.Domingo;
            diasSemana t = (diasSemana)2;
            int ds = (int)diasSemana.Sexta;

            Console.WriteLine("Dia D: {0}\nDia T: {1}\nSexta: {2}",d,t, ds);
        }
    }
}
