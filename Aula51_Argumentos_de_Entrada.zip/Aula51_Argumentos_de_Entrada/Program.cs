﻿using System;

namespace Aula51_Argumentos_de_Entrada
{
    class Program
    {
        //string[] args: onde eu recebo os parâmetros que eu passo
        //para o meu programa
        static void Main(string[] args)
        {
            int[] ent=new int[3]{1,2,3}; 
            int res=0;
            
            Console.WriteLine("----------------------------------------------------");
            Console.WriteLine("Verificando se foram passados parâmetros de entrada:");

            //verificando o que eu passei para o meu programa
            if(ent.Length>0){
                Console.WriteLine("Qtd de argumentos: {0}", ent.Length);
                for(int i=0; i < ent.Length; i++ ){
                    Console.WriteLine("Argumento {0}:{1}", i, ent[i]);
                    res += ent[i];
                }
            }else {
                Console.WriteLine("Não foram passados argumentos.");
            }
            Console.WriteLine("Soma dos argumentos: {0}", res);
        }
    }
}
