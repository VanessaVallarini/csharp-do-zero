using System;

static public class Jogador
{
    static public int energia;
    static public bool vivo;
    static public string nome;


    //SUBSTITUI O CONSTRUTOR
    static public void iniciar(string n)
    {
        energia = 100;
        vivo = true;
        nome = n;
    }
    
    static public void info()
    {
        Console.WriteLine("Nome Jogador...: {0}", nome);
        Console.WriteLine("Energia Jogador: {0}", energia);
        Console.WriteLine("Estado Jogador.: {0}\n", vivo);
    }
}