﻿using System;

namespace Aula31_Classes_static
{
    class Program
    {
        static void Main(string[] args)
        {
            Jogador.iniciar("Van");

            Jogador.info();

            Inimigo i1=new Inimigo("João");
            Inimigo i2=new Inimigo("José");
            Inimigo i3=new Inimigo("Paulo");

            Inimigo.alerta=true;

            i1.info();
            i2.info();
            i3.info();

        }
    }
}
