using System;

class Inimigo
{
    static public bool alerta; //quando for definido como true, todos os outros inimigos entram em estado de alerta
    public string nome;

    public Inimigo(string nome)
    {
        alerta = false;
        this.nome = nome;
    }

    public void info()
    {
        Console.WriteLine("Nome do inimigo..: {0}", nome);
        Console.WriteLine("Alerta do inimigo: {0}", alerta);
        Console.WriteLine("----------------------");
    }
}