﻿using System;

namespace Aula42_Indexadores_de_Classes
{
    class Program
    {
        static void Main(string[] args)
        {
            Carro c1 = new Carro();

            //usando o acesso set
            c1[4]=200;
            
            //usando o acesso get
            Console.WriteLine("Velocidade máxima: {0}", c1[4]);
        }
    }
}
