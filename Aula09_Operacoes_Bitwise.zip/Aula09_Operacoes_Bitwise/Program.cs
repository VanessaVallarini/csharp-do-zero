﻿using System;

namespace Aula09_Operacoes_Bitwise
{
    class Program
    {
        static void Main(string[] args)
        {
            //Serve para deslocar os bit pra direita ou para esquerda em variáveis inteiras
            //<< direita: dobra o valor da variável
            //>> esquerda: diminuir pela metade o valor da variável
            //Exemplo <<:
            //00001010 = bit 10
            //00010100 = bit 20
            //Exemplo >>:
            //00011010 = bit 26
            //00001101 = bit 13

            int num=10;
            //num=num<<1;
            num=num>>1;

            Console.WriteLine(num);


        }
    }
}
