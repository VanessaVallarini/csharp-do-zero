﻿using System;

namespace Aula41_GET_e_SET
{
    class Program
    {
        static void Main(string[] args)
        {
            Carro c1 = new Carro();

            //usando o acesso set
            c1.vm=500;
            
            //usando o acesso get
            Console.WriteLine("Velocidade máxima: {0}", c1.vm);
        }
    }
}
