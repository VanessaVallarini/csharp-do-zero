using System;

public class Carro{
    private int velMax;
    public int vm{
        get{
            return velMax;
        }
        set{
            if(value < 0){
                velMax = 0;
            } else if(value > 300){
                velMax = 300;
            } else{
                velMax = value;
            }
        }
    }

    //poderia utilizar apenas para leitura
    //public int vm{
        //get{

        //}
    //}

    //poderia utilizar apenas para escrita
    //public int vm{
        //set{

        //}
    //}

    public Carro(){
        //velMax=120;
        vm=120;
    }

    //atribuir valor para velMax
    //public void vm(int velMax)
    //{
        //this.velMax=velMax;
    //}
}