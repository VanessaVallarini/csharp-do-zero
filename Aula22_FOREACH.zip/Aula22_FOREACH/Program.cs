﻿using System;

namespace Aula22_FOREACH
{
    class Program
    {
        static void Main(string[] args)
        {
            //FOREACH: Serve para iterar e ler elementos de uma coleção
            //Não vamos atribuir valores em uma coleção e sim ler

            int[] num=new int[5]{11,22,33,44,55};

            //atribuição e inicialização
            /*for(int i=0;i<num.Length;i++)
            {
                Console.WriteLine("For pos{0}, valor num[{1}] ",i, num[i]);
            }*/

            //leitura
            //(variável para receber a coleção, deve ser do mesmo tipo)
            foreach (int n in num) 
            {
                Console.WriteLine(n);
            }
        }
    }
}
