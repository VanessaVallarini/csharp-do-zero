﻿using System;

namespace Aula36_Protected
{
    class Program
    {
        static void Main(string[] args)
        {
            Carro c1 = new Carro("Fusca",120);

            Console.WriteLine("Nome:.................{0}", c1.nome);
            Console.WriteLine("Velocidade máxima:....{0}", c1.getVelMax());
            Console.WriteLine("Ligado ou desligado?:.{0}", c1.getLigado());
        }
    }
}
