using System;

public class Carro:Veiculo{//Derivada de veículo
    public string nome;

    //inicializando o construtor da classe base
    public Carro(string nome, int vm):base(vm){
        this.nome=nome;
        ligado=true;
    }


}