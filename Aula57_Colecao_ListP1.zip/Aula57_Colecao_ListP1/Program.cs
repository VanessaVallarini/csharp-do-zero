﻿using System;
using System.Collections.Generic;
namespace Aula57_Colecao_ListP1
{
    class Program
    {
        static void Main(string[] args)
        {
            List<string> carros = new List<string>();
            List<string> carros2 = new List<string>();
            string[] carros3 = new string[6];

            //adicionando elementos
            Console.WriteLine("ADICIONANDO ELEMENTOS EM CARROS:");
            carros.Add("Golf");
            carros.Add("HRV");
            carros.Add("Focus");
            carros.Add("Argo");
            //lendo elementos
            foreach(string c in carros){
                Console.WriteLine("Carros: {0} ", c);
            }
            Console.WriteLine("--------------------------------");

            //adicionando uma série de elementos (carros em carros2)
            Console.WriteLine("ADICIONANDO CARROS EM CARROS2:");
            carros2.AddRange(carros);
            //lendo elementos
            foreach(string c in carros2){
                Console.WriteLine("Carros2: {0} ", c);
            }
            Console.WriteLine("--------------------------------");

            //removendo elementos
            Console.WriteLine("REMOVENDO ELEMENTOS DE CARROS:");
            carros.Clear();
            //lendo elementos
            foreach(string c in carros){
                Console.WriteLine("Carros: {0} ", c);
            }
            Console.WriteLine("--------------------------------");

            //verificando se existe um determinado elemento na lista
            Console.WriteLine("EXISTE Golf EM CARROS2?");
            if(carros2.Contains("Golf")){
                Console.WriteLine("Contém.");
            } else{
                Console.WriteLine("NÃO Contém.");
            }
            Console.WriteLine("--------------------------------");

            //Copiando Carros2 para Carros3 a partir de um determinado elemento
            Console.WriteLine("ADICIONANDO CARROS2 EM CARROS3 A PARTIR DE UMA DETERMINADA POSIÇÃO:");
            carros2.CopyTo(carros3, 2);
            //lendo elementos
            foreach(string c in carros3){
                Console.WriteLine("Carros3: {0} ", c);
            }
            Console.WriteLine("--------------------------------");

            //retornando o índice da primeira ocorrência encontrada
            Console.WriteLine("RETORNANDO O ÍNDICE DA PRIMEIRA OCORRÊNCIA:");
            string elemento = "HRV";
            int pos = 0;
            pos = carros2.IndexOf(elemento);
            Console.WriteLine("Índice de {0} em Carros2: {1} ", elemento, pos);
            Console.WriteLine("--------------------------------");

            //inserir elementos em uma determinada posição
            Console.WriteLine("INSERINDO UM ELEMENTO EM UMA DETERMINADA POSIÇÃO:");
            carros2.Insert(1,"Cruze");
            //lendo elementos
            foreach(string c in carros2){
                Console.WriteLine("Carros2: {0} ", c);
            }
            Console.WriteLine("--------------------------------");

            
            //pegando o último resultado que deu match no parâmetro informado
            carros2.Add("Argo");
            Console.WriteLine("RETORNANDO O ÍNDICE DA ÚLTIMA OCORRÊNCIA:");
            int posLIO = carros2.LastIndexOf("Argo");
            Console.WriteLine("Índeice da última ocorrência == Argo: {0} ", posLIO);
            //lendo elementos
            foreach(string c in carros2){
                Console.WriteLine("Carros2: {0} ", c);
            }
            Console.WriteLine("--------------------------------");

            //removendo um determinado elemento
            Console.WriteLine("REMOVENDO UM DETERMINADO ELEMENTO: GOLF");
            carros2.Remove("Golf");
            //lendo elementos
            foreach(string c in carros2){
                Console.WriteLine("Carros2: {0} ", c);
            }
            Console.WriteLine("--------------------------------");

             //removendo um elemento de uma determinada posição
            Console.WriteLine("REMOVENDO O ELEMENTO DA POSIÇÃO 4:");
            carros2.RemoveAt(4);
            //lendo elementos
            foreach(string c in carros2){
                Console.WriteLine("Carros2: {0} ", c);
            }
            Console.WriteLine("--------------------------------");

            //inverter a lista
            Console.WriteLine("INVERTER A POSIÇÃO DOS ELEMENTOS:");
            carros2.Reverse();
            //lendo elementos
            foreach(string c in carros2){
                Console.WriteLine("Carros2: {0} ", c);
            }
            Console.WriteLine("--------------------------------");

            //ordenando os elementos da lista por ordem alfabética
            Console.WriteLine("ORDENANDO OS ELEMENTOS:");
            carros2.Sort();
            //lendo elementos
            foreach(string c in carros2){
                Console.WriteLine("Carros2: {0} ", c);
            }
            Console.WriteLine("--------------------------------");

            //tamanho 
            Console.WriteLine("TAMANHO DA LISTA:");
            int tamanho = carros2.Count;
            Console.WriteLine("Qtd de elementos em Carros2: {0} ", tamanho);
            Console.WriteLine("--------------------------------");

            //retorna a capacidade da nossa lista 
            Console.WriteLine("CAPACIDADE DA LISTA:");
            int capacidade = carros2.Capacity;
            Console.WriteLine("Capacidade de Carros2: {0} ", capacidade);
            Console.WriteLine("--------------------------------");

            //define a capacidade da nossa lista 
            Console.WriteLine("CAPACIDADE DA LISTA:");
            carros2.Capacity=15;
            int capacidade2 = carros2.Capacity;
            Console.WriteLine("Capacidade de Carros2: {0} ", capacidade2);
            Console.WriteLine("--------------------------------");
        }
    }
}
