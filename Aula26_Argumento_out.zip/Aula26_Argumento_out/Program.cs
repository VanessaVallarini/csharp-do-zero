﻿using System;

namespace Aula26_Argumento_out
{
    class Program
    {
        //Pra que serve o out?
        //Permite o meu método retornar mais de um valor, seja 2 ou 10, enfim...
        //Só colocar os argumentos out na chamada do método e na implementação do mesmo
        //O resto é um ponteiro para associar o endereço da memória e o endereço do parâmetro
        static void Main(string[] args)
        {
            int divid, divis, quoc, rest;

            divid=10;
            divis=5;
            quoc=divide(divid, divis, out rest);

            Console.WriteLine("{0} / {1}: quociente={2} e resto={3}",divid, divis, quoc, rest);

        }

        /* static int divide(int dividendo, int divisor){
            int quociente, resto;
            quociente=dividendo/divisor;
            resto=dividendo%divisor;//resto divisão
            return quociente;
            //poderia colocar mais de um retorno, mas não é válido:
            return resto;
            return quociente, resto;
        } */

        static int divide(int dividendo, int divisor, out int resto){
            int quociente;
            quociente=dividendo/divisor;
            resto=dividendo%divisor;//resto divisão
            return quociente;
        }

    }
}
