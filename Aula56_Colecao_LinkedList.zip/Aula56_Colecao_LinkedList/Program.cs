﻿using System;
using System.Collections.Generic;

namespace Aula56_Colecao_LinkedList
{
    class Program
    {
        static void Main(string[] args)
        {
            LinkedList<string> trans = new LinkedList<string>();
            //adicionar um elemento no início da lista
            Console.WriteLine("ADD NO INÍCIO DA LISTA");
            trans.AddFirst("carro");
            trans.AddFirst("avião");
            trans.AddFirst("navio");
            trans.AddFirst("moto");
            //lendo os elementos
            foreach(string t in trans){
                Console.WriteLine("Transporte: {0}", t);
            }
            Console.WriteLine("----------------------");

            //adicionar um elemento no fim da lista
            Console.WriteLine("ADD NO FIM DA LISTA");
            trans.AddLast("bicicleta");
            //lendo os elementos
            foreach(string t in trans){
                Console.WriteLine("Transporte: {0}", t);
            }
            Console.WriteLine("----------------------");

            //adicionar um elemento após um determinado elemento
            Console.WriteLine("ADD APÓS NAVIO");
            LinkedListNode<string> noAfter;
            noAfter = trans.FindLast("navio");
            trans.AddAfter(noAfter, "patinete");
            //lendo os elementos
            foreach(string t in trans){
                Console.WriteLine("Transporte: {0}", t);
            }
            Console.WriteLine("----------------------");

            //adicionar um elemento antes um determinado elemento
            Console.WriteLine("ADD ANTES NAVIO");
            LinkedListNode<string> noBefore;
            noBefore = trans.FindLast("navio");
            trans.AddBefore(noAfter, "patins");
            //lendo os elementos
            foreach(string t in trans){
                Console.WriteLine("Transporte: {0}", t);
            }
            Console.WriteLine("----------------------");

            //verificando se existe um determinado elemento
            Console.WriteLine("EXISTE CARRO?");
            if(trans.Find("carro") ==null){
                Console.WriteLine("Não encontrado");
            }else{
                Console.WriteLine("Encontrado");
            }
            Console.WriteLine("----------------------");

            //removendo UM elemento
            Console.WriteLine("REMOVENDO NAVIO");
            trans.Remove("navio");
            //lendo os elementos
            foreach(string t in trans){
                Console.WriteLine("Transporte: {0}", t);
            }
            Console.WriteLine("----------------------");

            //removendo o primeiro elemento
            Console.WriteLine("REMOVENDO PRIMEIRO ELEMENTO");
            trans.RemoveFirst();
            //lendo os elementos
            foreach(string t in trans){
                Console.WriteLine("Transporte: {0}", t);
            }
            Console.WriteLine("----------------------");

            //removendo o ÚLTIMO elemento
            Console.WriteLine("REMOVENDO ÚLTIMO ELEMENTO");
            trans.RemoveLast();
            //lendo os elementos
            foreach(string t in trans){
                Console.WriteLine("Transporte: {0}", t);
            }
            Console.WriteLine("----------------------");

            //adicionar um elemento após, após um determinado elemento utilizando o NEXT
            Console.WriteLine("ADD APÓS, APÓS PATINETE");
            LinkedListNode<string> noAfter2;
            noAfter2 = trans.FindLast("patinete").Next;
            trans.AddAfter(noAfter2, "skate");
            //lendo os elementos
            foreach(string t in trans){
                Console.WriteLine("Transporte: {0}", t);
            }
            Console.WriteLine("----------------------");

            //adicionar um elemento antes, antes um determinado elemento utilizando o Previous
            Console.WriteLine("ADD ANTES, ANTES DE CARRO");
            LinkedListNode<string> noBefore2;
            noBefore2 = trans.FindLast("carro").Previous;
            trans.AddBefore(noBefore2, "roller");
            //lendo os elementos
            foreach(string t in trans){
                Console.WriteLine("Transporte: {0}", t);
            }
            Console.WriteLine("----------------------");

             //substituir um determinado elemento utilizando o Value
            Console.WriteLine("ADD SOBRE CARRO");
            trans.Find("carro").Value = "canoa";
            //lendo os elementos
            foreach(string t in trans){
                Console.WriteLine("Transporte: {0}", t);
            }
            Console.WriteLine("----------------------");

            //removendo todos os elementos
            Console.WriteLine("REMOVENDO TODOS OS ELEMENTOS");
            trans.Clear();
            //lendo os elementos
            foreach(string t in trans){
                Console.WriteLine("Transporte: {0}", t);
            }
        }
    }
}
