using System;

public class Calc{
    
    //Fatorial de 5:
    //5! = 5*4*3*2*1
    //nessa caso vamos utilizar a recursividade no lugar do for()

    public int fat(int f){
        int res;
        if(f<=1){
            res=1;
        }else{
            res = f*fat(f-1);
        }
        return res;
    }
}