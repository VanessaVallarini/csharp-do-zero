﻿using System;

namespace Aula48_Recursividade
{
    class Program
    {
        static void Main(string[] args)
        {
            int res;
            Calc calc = new Calc();
            res=calc.fat(5);
            Console.WriteLine(res);
        }
    }
}
