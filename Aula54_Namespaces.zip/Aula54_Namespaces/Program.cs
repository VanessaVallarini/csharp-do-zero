﻿using System;

namespace Aula54_Namespaces
{
    class Program
    {
        static void Main(string[] args)
        {
            float area=0;
            try
            {
                area=Calc1.Area.Quadrado(0, 5F);
                Console.WriteLine("Area do quadrado: {0}", area);
            }catch (Exception e)
            {
                Console.WriteLine("ERRO: {0}", e.Message);
            }finally{
                 Console.WriteLine("Fim do programa.");
            }
        }
    }
}
