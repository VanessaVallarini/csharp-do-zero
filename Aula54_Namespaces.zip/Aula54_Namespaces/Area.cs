using System;

namespace Calc1
{
    public class Area
    {
        public static float Quadrado(float bas, float alt)
        {
            if (bas == 0 || alt == 0)
            {
                throw new Exception("Base e altura não podem ser igual a zero!");
            }
            return bas * alt;
        }

    }
}

namespace Calc2
{
    public class Area
    {
        public static float Quadrado(float bas, float alt)
        {
            if (bas == 0 || alt == 0)
            {
                throw new Exception("Base e altura não podem ser igual a zero!");
            }
            return bas * alt;
        }

    }
}