﻿using System;

namespace Aula45_Array_de_Estruturas
{
    class Program
    {
        static void Main(string[] args)
        {
            //Criando um array de inteiros
            int[] numeros = new int[10];

            Carro[] carros = new Carro[2];

            carros[0].marca = "HONDA";
            carros[0].modelo = "HRV";
            carros[0].cor = "VINHO";

            carros[1].marca = "VW";
            carros[1].modelo = "FUSCA";
            carros[1].cor = "VERDE";

            for(int i=0; i<carros.Length; i++){
                carros[i].info();
            }

        }
    }
}
