using System;

public struct Carro{
    public string marca;
    public string modelo;
    public string cor;

    public void info(){
        Console.WriteLine("Marca:..{0}", marca);
        Console.WriteLine("Modelo:.{0}", modelo);
        Console.WriteLine("Cor:....{0}", cor);
        Console.WriteLine("--------------------");
    }

}