﻿using System;

namespace Aula20_WHILE
{
    class Program
    {
        static void Main(string[] args)
        {
            //WHILE: ENQUANTO
            //Diferente para for: aqui eu não sei qts vezes vou rpetir o loop

            int[] num=new int[10];
            int i=0;

            //enquanto(expressção lógica for verdadeira) o loop acontece
            //obs: o contador deve ser criado fora do while para não criarmos um
            //loop infinito
            while(i<num.Length)
            {
                num[i]=i;
                Console.WriteLine("O valor de num na pos{0} é: {1}", i, num[i]);
                i++;
            }
            Console.WriteLine("Fim do loop");
        }
    }
}
