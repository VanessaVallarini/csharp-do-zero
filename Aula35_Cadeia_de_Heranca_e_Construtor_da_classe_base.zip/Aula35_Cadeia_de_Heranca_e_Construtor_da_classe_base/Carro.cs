using System;
//Classe derivada da classe Veiculo
public class Carro:Veiculo{
    public string nome;
    public string cor;

    //inicializando o construtor da classe base, cuja aceita 
    //apenas 1 argumento int
    public Carro(string nome, string cor):base(4){
        desligar();
        //Agora por ser private não pode ser chamada diretamente 
        //rodas=4;
        velMax=120;
        this.nome=nome;
        this.cor=cor;
    }


}