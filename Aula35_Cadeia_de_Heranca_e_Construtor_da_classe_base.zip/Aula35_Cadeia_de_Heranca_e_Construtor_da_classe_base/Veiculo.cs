using System;

//Classe Base
public class Veiculo
{
    public int velMax;
    public int rodas;
    private bool ligado;

    public Veiculo(int rodas)
    {
        this.rodas = rodas;
    }
    public void ligar()
    {
        ligado = true;
    }

    public void desligar()
    {
        ligado = false;
    }

    public string getLigado()
    {
        //resumindo todo o código abaixo
        //podemos utilizar o operador ternário
        //como funciona: 
        //o que eu quero testar
        //primeiro resultado é quando é true
        //segundo resultado é quando é false
        return (ligado?"Sim":"Não");
        /* if (ligado)
        {
            return "Sim";
        }
        else
        {
            return "Não";
        } */
    }

    public int getRodas()
    {
        return rodas;
    }

    //limitando o número de rodas
    public void setRodas(int rodas)
    {
        if(rodas<0){
            this.rodas=0;
        }else if(rodas>40){
            this.rodas=40;
        }else{
            this.rodas=rodas;
        }
    }
}