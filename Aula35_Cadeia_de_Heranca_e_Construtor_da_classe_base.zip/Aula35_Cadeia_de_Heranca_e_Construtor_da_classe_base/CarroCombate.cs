using System;
//Classe derivada da classe Carro
//Tudo o que tiver como public em Veiculo conseguimos acessar em Carro e CarroCombate
public class CarroCombate:Carro{
    public int municao;

    public CarroCombate():base("Carro de Combate", "verde"){
        municao=100;
        setRodas(6);
    }
}