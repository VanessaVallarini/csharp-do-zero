﻿using System;

namespace Aula35_Cadeia_de_Heranca_e_Construtor_da_classe_base
{
    class Program
    {
        static void Main(string[] args)
        {
            Carro c1 = new Carro("Fusca", "vermelho");

            CarroCombate cc1 = new CarroCombate();

            Console.WriteLine("CARRO");
            Console.WriteLine("Velocidade:.{0}", c1.velMax);
            //métodos privados apenas através dos métodos get
            Console.WriteLine("Rodas:......{0}", c1.getRodas());
            Console.WriteLine("Ligado?:....{0}", c1.getLigado());
            Console.WriteLine("Nome:.......{0}", c1.nome);
            Console.WriteLine("Cor:....... {0}", c1.cor);
            Console.WriteLine("---------------------------------");
            Console.WriteLine("CARRO COMBATE");
            Console.WriteLine("Velocidade:.{0}", cc1.velMax);
            //métodos privados apenas através dos métodos get
            Console.WriteLine("Rodas:......{0}", cc1.getRodas());
            Console.WriteLine("Ligado?:....{0}", cc1.getLigado());
            Console.WriteLine("Nome:.......{0}", cc1.nome);
            Console.WriteLine("Cor:....... {0}", cc1.cor);
            Console.WriteLine("Munição:....... {0}", cc1.municao);
            Console.WriteLine("---------------------------------");
        }
    }
}
