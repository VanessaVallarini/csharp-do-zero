﻿using System;

namespace Aula21_DO_WHILE
{
    class Program
    {
        static void Main(string[] args)
        {
            //DO WHILE
            //Diferença para while: garanto que pelo menos uma vez os comandos serão executados

            //Exemplo de diferença entre do while e while
            int num=5;

            while(num<5)
            {
                Console.WriteLine("while");
            }
            
            do
            {
                Console.WriteLine("do while");
            }while(num<5);

            string senha="123";
            string senhaUser;
            int tentativas=0;

            do
            {
                Console.Clear();
                Console.WriteLine("Digite a senha: ");
                senhaUser=Console.ReadLine();
                tentativas++;
            }while(senha != senhaUser);

            Console.WriteLine("Senha correta, tentativas: {0}", tentativas);
            
        }
    }
}
