﻿using System;

namespace Aula33_Public_vs_Private
{
    class Program
    {
        static void Main(string[] args)
        {
            Jogador j1 = new Jogador("Vanessa");
            
            j1.setEnergia(-30);
            j1.setEnergia(40);

            Console.WriteLine("Nome jogador...: {0}", j1.getNome());
            Console.WriteLine("Energia jogador: {0}", j1.getEnergia());
        }
    }
}
