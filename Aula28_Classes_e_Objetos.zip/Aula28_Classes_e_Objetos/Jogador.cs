public class Jogador
    {
        public int energia=100;
        public bool vivo=true;
    }