﻿using System;

namespace Aula28_Classes_e_Objetos
{
    class Program
    {
        static void Main(string[] args)
        {
            Jogador j1=new Jogador();
            Jogador j2=new Jogador();
            Jogador j3=new Jogador();

            Console.WriteLine("Energia do jogador 1: {0}", j1.energia);

            j2.energia=50;// com o atibuto público eu consigo alterar seu valor

            Console.WriteLine("Energia do jogador 2: {0}", j2.energia);
            
            Console.WriteLine("Energia do jogador 3: {0}", j3.energia);
            //cada jogador possui um endereço diferente na memória e são independentes
        }
    }
}
