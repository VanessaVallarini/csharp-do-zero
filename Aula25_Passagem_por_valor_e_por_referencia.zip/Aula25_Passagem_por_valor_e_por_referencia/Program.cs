﻿using System;

namespace Aula25_Passagem_por_valor_e_por_referencia
{
    class Program
    {
        //O que a passagem por referência faz?
        //Usa o endereço de memória da variável que foi passada como argumento 
        static void Main(string[] args)
        {
            int num1=50;
            int num2=50;

            dobrar1(ref num1);
            Console.WriteLine("Valor por referência: 50*2 = {0}",num1);

            dobrar2(num2);
            Console.WriteLine("Valor por não referência: 50*2 = {0}",num2);
        }

        static void dobrar1(ref int valor){
            valor*=2;
        }

        static void dobrar2(int valor){
            valor*=2;
        }
    }
}
