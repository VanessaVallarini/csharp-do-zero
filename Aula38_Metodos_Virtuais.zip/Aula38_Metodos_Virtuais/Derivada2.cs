using System;

public class Derivada2:Derivada1{

    public Derivada2(){
        Console.WriteLine("Construtor Derivada2");
    }

     override public void info(){
        Console.WriteLine("Derivada2");
    }
}