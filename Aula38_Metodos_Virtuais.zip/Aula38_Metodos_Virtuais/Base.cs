using System;

public class Base{

    public Base(){
        Console.WriteLine("Construtor Base");
    }

    //virtual: permite a reescrita do método
    /* virtual public void info(){
        Console.WriteLine("Base");
    } */

    //Nem precisamos inserir uma operação dentro do método
    //já que o mesmo será sobrescrito
    virtual public void info(){}
}