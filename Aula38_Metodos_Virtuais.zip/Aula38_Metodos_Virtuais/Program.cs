﻿using System;

namespace Aula38_Metodos_Virtuais
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("CONSTRUTORES-------------------------");
            //poderia instanciar a classe base
            //mas nesse caso quero apenas referenciar a derivada1 e 2
            //Base b1 = new Base();
            Base Ref;
            Derivada1 d1 = new Derivada1();
            Derivada2 d2 = new Derivada2();
            Console.WriteLine("\nMÉTODOS------------------------------");
            //para exibir o resultado da operação do método
            //info, tanto da derivada1 quanto da 2, basta instanciá-los
            //d1.info();
            //d2.info();
            Ref=d1;
            Ref.info();

            Ref=d2;
            Ref.info();
        }
    }
}
