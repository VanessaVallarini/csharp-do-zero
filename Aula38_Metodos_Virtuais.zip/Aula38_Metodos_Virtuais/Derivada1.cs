using System;

public class Derivada1:Base{

    public Derivada1(){
        Console.WriteLine("Construtor Derivada1");
    }

    //override informa que está sobrescrevendo um método da classe base
    //com isso, mesmo eu chamando o método da classe Derivada2
    //o resultado que será executado é a operação do método dessa classe
    //cujo sobrescreveu o método da classe base
    //isso se eu não tivesse esse método na classe Derivada2
    override public void info(){
        Console.WriteLine("Derivada1");
    }
}