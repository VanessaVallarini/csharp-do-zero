﻿using System;

namespace Aula46_Metodos_Que_Retornam_Objetos
{
    class Program
    {
        static void Main(string[] args)
        {
            Galinha g1 = new Galinha("Daniela");
            Galinha g2 = new Galinha("Daniela2");
            Galinha g3 = new Galinha("Daniela3");

            g1.botar();
            g1.botar();

            g2.botar();
            g2.botar();

            g3.botar();
            g3.botar();
            g3.botar();

            g3.getControle();


        }
    }
}
