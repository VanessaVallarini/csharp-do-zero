using System;

public class Galinha{
    private static int controle;
    private string nomeGalinha;
    private int numOvo;
    public Galinha(string nomeGalinha){
        this.nomeGalinha=nomeGalinha;
        numOvo=0;
    }
    public Ovo botar(){
        numOvo++;
        controle++;
        return new Ovo(numOvo,nomeGalinha,controle);
    }

    public void getControle(){
        Console.WriteLine("Total de ovos: {0}", Ovo.controle);
    }
}