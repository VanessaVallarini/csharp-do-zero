using System;

public class Ovo{
    public static int controle;
    private int numOvo;
    private string minhaGalinha;
    public Ovo(int numOvo, string minhaGalinha, int cont){
        this.numOvo=numOvo;
        this.minhaGalinha=minhaGalinha;
        controle=cont;
        Console.WriteLine("Ovo criado: {0} - {1}", this.numOvo, this.minhaGalinha);
    }
    
}