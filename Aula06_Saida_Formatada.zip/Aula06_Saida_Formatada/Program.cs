﻿using System;

namespace Aula06_Saida_Formatada
{
    class Program
    {
        static void Main(string[] args)
        {
            //int n1, n2, n3;

            //n1=10; n2=20; n3=30;

            //Quebra de Linha
            //Console.WriteLine("Quebra Linha");
            //Console.Write("Não Quebra Linha");
            //Console.WriteLine("Olha como não quebra Linha");

            //Índices:
            //Console.Write(n1 + "," + n2 + "," + n3);
            //Console.WriteLine("N1={0}, N2={1}, N3={2}", n1, n2, n3);

            //Índices com quebra de linha:
            //Console.WriteLine(" N1={0},\n N2={1},\n N3={2}", n1, n2, n3);

            //Índices com tabulação:
            //Console.WriteLine("\nN1=\t{0} \nN2=\t{1} \nN3=\t{2}", n1, n2, n3);

            string produto = "Pastel";
            double valorCompra=5.50;
            double valorVenda;
            double lucro=0.1;

            valorVenda=valorCompra+(valorCompra*lucro); //por quanto eu tenho que vender

            Console.WriteLine("Produto.......:{0,15}", produto); //0,15 é o espaço entre a plavra "produto......." e a variável
            Console.WriteLine("Val. Compra...:{0,15:c}", valorCompra); //c é o formato dinheiro
            Console.WriteLine("Lucro.........:{0,15:p}", lucro); //p é o formato porcentagem
            Console.WriteLine("Val. Venda....:{0,15:c}", valorVenda); 
            

        }
    }
}
