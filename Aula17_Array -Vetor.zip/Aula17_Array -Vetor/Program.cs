﻿using System;

namespace Aula17_Array__Vetor
{
    class Program
    {
        static void Main(string[] args)
        {
            //vai armazenar elementos do tipo inteiro e irá conter 5 elementos [0 a 4]

            //Formar de declarar
            int[] n=new int[5]; 
            int[] num=new int[3]{55,77,99};
            //nesse caso o array tem o tamanho do número de índices que atribuímos
            int[] num2={66,88,100}; 

            //adicionando elementos no array:
            n[0]=111;
            n[1]=222;
            n[2]=333;
            n[3]=444;
            n[4]=555;

            Console.WriteLine(n[0]);
            Console.WriteLine(num[2]);
            Console.WriteLine(num2[3]);
        }
    }
}
