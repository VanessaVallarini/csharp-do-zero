﻿using System;

namespace Aula07_Constantes
{
    class Program
    {
        static void Main(string[] args)
        {
            //Costante: o seu valor é imutável. Recebe seu valor na declaração, atribuição e apenas
            const string curso="curso";
            const double pi=3.1415;
            
            // se eu tentar atribuir valor na constante dá erro:
            //curso="bruno";

            Console.WriteLine("Estou fazendo: {0}\nConstante: {1}", curso, pi);
        }
    }
}
