﻿using System;

namespace Aula05_Operadores_e_Operacoes
{
    class Program
    {
        static void Main(string[] args)
        {
            //soma
            int res0=10+5;

            //multiplicação. Soma vem antes da multiplicação, ou seja
            //se não colocarmos o parêntese o resultado será de 
            //5*2+10
            int res1=(10+5)*2;
            int res2=10+5*2;

            Console.WriteLine("res1 = " + res1);
            Console.WriteLine("res2 = " +res2);

            //True or False?
            bool resBoll=10<5;
            Console.WriteLine("Res é menor que 5? = " + resBoll);

            //Relacionais
            //> maior; 
            //< menor; 
            //>= maior ou igual;
            //<= menor ou igual;
            //!= diferente;
            //+= incrementando
            //variavel++ incrementando


            int num=10;
            //ao invés de:
            int soma1=num+1;
            //usa-se (posso usar para soma, diminuição, divisão ou multiplicação):
            int soma2=num+=1;
            //ou melhor ainda (apenas quando é incremento pelo mesmo valor):
            int soma3=num++;

            Console.WriteLine(soma1);
            Console.WriteLine(soma2);
            Console.WriteLine(soma3);

            int num2=10;
            int num3=10;
            int num4=10;

            int diminuir=num2-=1;
            int dividir=num3/=2;
            int multiplicar=num4*=2;
            Console.WriteLine("diminuir = " + diminuir);
            Console.WriteLine("dividir = " + dividir);
            Console.WriteLine("multiplicar = " + multiplicar);


            // & = END / E 
            // | = OR / OU

            //OR: retorna verdadeiro se uma das operações retornar verdadeiro
            bool endOr=(5>3)|(10<5);
            bool endOr2=(5>7)|(10<5);
            //END: retorna verdadeiro se todas as operações retornar verdadeiro
            bool endOr3=(5>3)&(10<5);
            
            Console.WriteLine(endOr);
            Console.WriteLine(endOr2);
            Console.WriteLine(endOr3);
        }
    }
}
