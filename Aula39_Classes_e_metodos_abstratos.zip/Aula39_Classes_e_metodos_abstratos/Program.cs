﻿using System;

namespace Aula39_Classes_e_metodos_abstratos
{
    class Program
    {
        static void Main(string[] args)
        {
            Carro c1 = new Carro();

            c1.setLigado(true);
            c1.aceleracao(5);

            Console.WriteLine("Ligado?: {0}", c1.getLigado());
            Console.WriteLine("Velocidade atual: {0}", c1.getVelAtual());
            
        }
    }
}
