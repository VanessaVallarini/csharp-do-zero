using System;

public abstract class Veiculo
{
    protected int velMaxima;
    protected int velAtual;
    protected bool ligado;

    //construtor não é abstrato, portanto, preciso implementar o seu conteúdo
    public Veiculo()
    {
        ligado = false;
        velAtual = 0;
    }

    //método não é abstrato, portanto, preciso implementar o seu conteúdo
    public void setLigado(bool ligado)
    {
        this.ligado=ligado;
    }

    public bool getLigado()
    {
        return ligado;
    }

    //método é abstrato, portanto, preciso implementar na classeque irá herdar
    abstract public void aceleracao(int mult);

     public int getVelAtual()
    {
        return velAtual;
    }
}