using System;

public class Carro:Veiculo{

    public Carro(){
        velMaxima=120;
    }

    public override void aceleracao(int mult)
    {
        velAtual+=10*mult;
        //se eu receber um número negativo, estou diminuindo a aceleracao;
        //se eu receber um número positivo, estou aumentando a aceleracao;
    }
}