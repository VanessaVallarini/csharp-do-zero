﻿using System;

namespace Aula47_Sobrecarga_De_Metodos
{
    class Program
    {
        static void Main(string[] args)
        {
            int res;
            Calc calc = new Calc();

            res = calc.soma(10,5);
            Console.WriteLine(res);

            res = calc.soma(10,5,20);
            Console.WriteLine(res);

            double resD = calc.soma(10.5,10.5,10.3);
            Console.WriteLine(res);

            res = calc.soma(10,10,10,10,10,10,10,10,10,10);
            Console.WriteLine(res);

        }
    }
}
