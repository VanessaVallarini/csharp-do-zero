using System;

public class Calc{
    public int soma(int n1, int n2){
        return n1+n2;
    }

    //posso criar métodos com o mesmo nome
    //desde que tenham parâmetros de entrada diferentes
    public int soma(int n1, int n2, int n3){
        return n1+n2+n3;
    }

    public double soma(double n1, double n2, double n3){
        return n1+n2+n3;
    }

    public int soma(params int[]n){
        int s=0;
        for(int i=0; i<n.Length; i++){
            s+=n[i];
        }
        return s;
    }
}