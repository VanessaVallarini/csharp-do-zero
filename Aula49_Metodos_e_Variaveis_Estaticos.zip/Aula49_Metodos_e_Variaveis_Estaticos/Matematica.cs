using System;

public class Matematica{
    public static double pi=3.14;

    public static int dobro(int n){
        return n*2;
    }
}