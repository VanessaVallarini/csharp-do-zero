﻿using System;

namespace Aula49_Metodos_e_Variaveis_Estaticos
{
    class Program
    {
        static void Main(string[] args)
        {
            double vpi=Matematica.pi;
            int valor=10;
            
            Console.WriteLine("Valor de PI:..{0}", vpi);
            Console.WriteLine("Dobro de {0}:.{1}", valor, Matematica.dobro(valor));
        }
    }
}
