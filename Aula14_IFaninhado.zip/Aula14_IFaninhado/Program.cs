﻿using System;

namespace Aula14_IFaninhado
{
    class Program
    {
        static void Main(string[] args)
        {
            //TESTES
            //nota >= 60 aprovado
            //nota >= 59 and <= 40 recuperação
            //nota < 59 reprovado

            int nota1, nota2, nota3, nota4, res;
            nota1=nota2=nota3=nota4=0;

            string resultado;

            Console.Write("Digite a nota 1: ");
            nota1=int.Parse(Console.ReadLine());

            Console.Write("Digite a nota 2: ");
            nota2=int.Parse(Console.ReadLine());

            Console.Write("Digite a nota 3: ");
            nota3=int.Parse(Console.ReadLine());

            Console.Write("Digite a nota 4: ");
            nota4=int.Parse(Console.ReadLine());

            res=(nota1+nota2+nota3+nota4)/4;

            if(res >= 60) //de baixo pra cima é mais fácil
            {
                if(res >= 90){
                    if(res >= 99){
                        resultado="Aprovado com super louvor"; 
                    }else{
                        resultado="Aprovado com louvor";
                    }
                }else{
                    resultado="Aprovado"; 
                }              
            }else{
                if(res >= 40){
                    resultado="Recuperação"; 
                }else{
                    resultado="Reprovado"; 
                } 
            }
            Console.WriteLine("Média: {0}\nResultado: {1}",res, resultado);
        }
    }
}
