﻿using System;

namespace Aula12_IF
{
    class Program
    {
        static void Main(string[] args)
        {
            //SE(EXPRESSÃO LÓGICA){}
            //SE(10 > 5){TRUE}
            //Operadores: > < >= <= == !=

            int nota1, nota2, nota3, nota4, res;
            nota1=nota2=nota3=nota4=0;

            string resultado="Reprovado";

            Console.Write("Digite a nota 1: ");
            nota1=int.Parse(Console.ReadLine());

            Console.Write("Digite a nota 2: ");
            nota2=int.Parse(Console.ReadLine());

            Console.Write("Digite a nota 3: ");
            nota3=int.Parse(Console.ReadLine());

            Console.Write("Digite a nota 4: ");
            nota4=int.Parse(Console.ReadLine());

            res=(nota1+nota2+nota3+nota4)/4;

            if(res >= 60)
            {
                resultado="Aprovado";
            }

            Console.WriteLine("Média: {0}\nResultado: {1}",res, resultado);
        }
    }
}
