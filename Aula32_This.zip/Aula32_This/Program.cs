﻿using System;

namespace Aula32_This
{
    class Program
    {
        static void Main(string[] args)
        {
            Calculos c = new Calculos(10,2);
            
            Console.WriteLine(c.Somar());

        }
    }
}
