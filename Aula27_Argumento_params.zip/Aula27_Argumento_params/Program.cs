﻿using System;

namespace Aula27_Argumento_params
{
    class Program
    {
        //Pra que serve o params???
        //Eu posso entrar no método sem especificar quantos parâmetros eu quero
        static void Main(string[] args)
        {
            soma(10,5,2,4,7);
        }

        /* static void soma(int n1, int n2){
            int res=n1+n2;
            Console.WriteLine("A soma de {0} + {1} = {3}", n1, n2, res);
        } */

        static void soma(params int[]n){
            //se foi entrado com zero valor: não da pra fazer nada
            //se foi entrado com 1 valor: apenas mostrar o valor
            //se foi com mais de 1 valor: percorrer o array e somar cada valor
            int res=0;
            if(n.Length < 1){
                Console.WriteLine("Não existem valores a serem somados.");
            } else if(n.Length < 2){
                Console.WriteLine("Valores insuficientes para soma: {0}.", n[0]);
            } else{
                for(int i=0;i < n.Length; i++){
                    res+=n[i];
                }
                Console.WriteLine("A soma dos valores é: {0}.", res);
            }
            
        }

    }
}
