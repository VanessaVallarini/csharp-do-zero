using System;

public class Base{

    public Base(){
        Console.WriteLine("Construtor Base");
    }
}