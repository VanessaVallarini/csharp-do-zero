using System;

public class Derivada1:Base{

    public Derivada1(){
        Console.WriteLine("Construtor Derivada1");
    }
}