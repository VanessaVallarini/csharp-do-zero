﻿using System;

namespace Aula37_Heranca_Ordem_execução_construtores
{
    class Program
    {
        static void Main(string[] args)
        {
            Derivada2 d2 = new Derivada2();
            
        }
    }
}
