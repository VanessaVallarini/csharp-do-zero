﻿using System;

namespace Aula40_Classe_Sealed
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");
        }
    }
}
