using System;

//Isso não pode
public class Carro: Veiculo
{

}

