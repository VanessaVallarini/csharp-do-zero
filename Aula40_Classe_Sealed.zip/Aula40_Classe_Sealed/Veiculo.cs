using System;

public sealed class Veiculo
{

}

//isso tb não pode
public abstract sealed class Veiculo
{
    
}