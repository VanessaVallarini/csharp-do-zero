﻿using System;

namespace Aula52_Excecoes_Try_Catch_Finally
{
    class Program
    {
        static void Main()
        {
            int n1=0, n2=0, res=0;
            n1=10;
            n2=0;
            //Erro ao dividirmos por 0:
            //Unhandled exception. System.DivideByZeroException: Attempted to divide by zero.
            
            try{//bloco que executa as operações
                res=n1/n2;
                Console.WriteLine("{0}/{1} = {2}", n1, n2, res);
            }catch(Exception e){//bloco que trata as exceções
                Console.WriteLine("ERRO: {0}", e.Message);
                //Console.WriteLine("Ex: {0}", e);
                Console.WriteLine("Tipo da Exceção: {0}", e.GetType());
            }

           /*  catch(DivideByZeroException e){//bloco que trata as exceções
                Console.WriteLine("ERRO: {0}", e.Message);
                Console.WriteLine("Ex: {0}", e);
                Console.WriteLine("Ex2: {0}", e.GetType());
            } */

            
            
        }
    }
}
