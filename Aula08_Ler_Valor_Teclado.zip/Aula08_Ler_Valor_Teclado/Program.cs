﻿using System;

namespace Aula08_Ler_Valor_Teclado
{
    class Program
    {
        static void Main(string[] args)
        {
            int v1, v2, soma;
            string nome;

            //Console.Write("Digite seu nome: ");
            //nome=Console.ReadLine();
            //Console.WriteLine("Nome digitado: {0}", nome);

            Console.Write("Digite o primeiro valor: ");
            //tudo o que é lido do teclado é lido no formato string
            //armazenar uma variável string em uma variável inteira é uma conversão explícita
            //ou seja, é uma conversão não segura, talvez seja de interferência do programador
            //eu preciso indicar que eu quero converter aquele dado que está vindo do teclado
            //no formato texto para inteiro
            //Ao invés de: v1=Console.ReadLine(); 
            //Usa-se:
            v1=Convert.ToInt32(Console.ReadLine());//mais adequado quando o dado não é confiável

            Console.Write("Digite o segundo valor: ");
            
            v2=int.Parse(Console.ReadLine());
            
            soma=v1+v2;

            Console.WriteLine("A soma de {0} + {1} = {2}", v1, v2,soma);


            


        }
    }
}
