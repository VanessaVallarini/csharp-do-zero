﻿using System;

namespace Aula11_Typecast
{
    class Program
    {
        static void Main(string[] args)
        {
            //Typecast: quando precisamos converter um tipo em outro
            //Quando a conversão não é implícita, ou seja, segura, recomenda-se a conversão de typecast

            //Exemplo conversão segura
            //int n1=10;
            //float n2=n1;
            //Console.WriteLine(n2);

            //Exemplo conversão não segura/ não implícita
            //float n1=10.5f;
            //int n2=(int)n1;//ty type cast
            //Console.WriteLine(n2);

            //Exemplo conversão não segura/ não implícita
            int vInt=10;
            short vShort=(short)vInt; //ty type cast
            Console.WriteLine(vShort);

        }
    }
}
