﻿using System;

namespace Aula03
{
    class Program
    {
        static void Main(string[] args)
        {
            //variável: armazena dados na memória ram através do nosso programa para armazenamento de dados
            
            int num=10;
            //int primitivo

            char letra='c';
            //char caracter

            float valor=5.3f;

            byte n1=10; 
            //armazena entre 0 e 255

            string nome="Vanessa";

            var aux=nome;
            //não especifico o tipo da variável

            Console.WriteLine("valor da variável aux: " + aux + "...");


            int num1=10, num2, num3, soma;
            //declarar várias variáveis do mesmo tipo

            num2=10;
            num3=10;
            soma=num1+num2+num3;

            Console.WriteLine("Soma de: " + num1 + " + " + num2 + " + " + num3 + " = " + soma);


            Console.WriteLine("Soma de: " + num1 + " + " + num2 + " + " + num3 + " = " + Convert.ToInt32(num1+num2+num3));





        }
    }
}
