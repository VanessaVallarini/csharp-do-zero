﻿using System;

namespace Aula16_goto
{
    class Program
    {
        static void Main(string[] args)
        {
             //gera um desvio no programa para um label determinado

            int tempo=0;
            char escolha;

            //qd o comando goto é acionado a execução do programa retorna pra cá
            inicio:

            //limpando o console
            Console.Clear();

            Console.WriteLine("BH a Vitoria/ES\nEscolha o transporte:");
            Console.WriteLine("(a) Avião\n(c) Carro\n(o) Ônibus)");

            escolha=char.Parse(Console.ReadLine());

            switch(escolha)
            {
                case 'a':
                case 'A':
                    tempo=50;
                    break;
                case 'c':
                case 'C':
                    tempo=480;
                    break;
                case 'o':
                case 'O':
                    tempo=660;
                    break;
                default:
                    tempo=-1; 
                    break;
            }

            if(tempo < 0)
            {
                Console.WriteLine("Transporte indisponível.");
            }else{
                Console.WriteLine("Tempo para o transporte escolhido: {0} minutos", tempo);
            }

            Console.Write("\nDeseja calcular outro transporte?[s/n]");
            escolha=char.Parse(Console.ReadLine());
            if(escolha=='s' || escolha=='S')
            {
                goto inicio;
            }else{
                Console.Clear();
                Console.WriteLine("Fim!");
            }
        }
    }
}
