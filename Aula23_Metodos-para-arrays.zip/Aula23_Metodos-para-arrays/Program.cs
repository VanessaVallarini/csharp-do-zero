﻿using System;

namespace Aula23_Metodos_para_arrays
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] vetor1=new int[5];
            int[] vetor2=new int[5];
            int[] vetor3=new int[5];
            int[,] matriz=new int[2,5]{{11,12,13,14,15},{21,22,23,24,25}};

            //gerar números aleatórios
            Random random=new Random();
            for(int i=0;i<vetor1.Length;i++){
                vetor1[i]=random.Next(50);//Máximo; .Next()- qualquer ou .Next(50,100) - mínimo e máximo
            }
            Console.WriteLine("Elmentos do vetor 1");
            foreach(int n in vetor1){
                Console.WriteLine(n);
            }

            //retornar posição do elemento procurado
            //Caso elemento não seja encontrado o valor retornado será -1
            //public static int BinarySearch(array, valor)
            Console.WriteLine("BinarySearch");
            int procurado=13;
            int pos=Array.BinarySearch(vetor1,procurado);
            Console.WriteLine("Valor {0} está na posição {1}", procurado, pos);
            Console.WriteLine("----------------------------------------");

            //Copia os elementos de um array para outro
            //(array origem, array destino, quantidade de elementos que eu quero copiar)
            //Foreach estou imprimindo os elementos copiados
            //public static void Copy(Ar_origem,Ar_destino,qtde_elementos);
            Console.WriteLine("Copy");
            Array.Copy(vetor1,vetor2,vetor1.Length);
            foreach(int n in vetor2){
                Console.WriteLine(n);
            }  
            Console.WriteLine("----------------------------------------");

            //public void CopyTo(Ar_destino,a_partir_desta_pos);
            Console.WriteLine("CopyTo");
            //a partir do vetor de origem o CopyTo copia pro vetor de destino vetor3
            //copiar a partir da posição 0
            vetor1.CopyTo(vetor3,0);
            //imprimindo os elementos do vetor3
            foreach(int n in vetor3){
                Console.WriteLine(n);
            }  
            Console.WriteLine("----------------------------------------");

            //public long GetLongLenght(dimensão);
            Console.WriteLine("GetLongLenght");
            long qtdeElementosVetor=vetor1.GetLongLength(0);
            Console.WriteLine("Quantidade de elementos {0}", qtdeElementosVetor);
            Console.WriteLine("----------------------------------------");

            //retorna o menor índice do vetor ou matriz
            //a dimensão irá informar se é uma matriz ou array
            //vetor tem dimenção 0
            //a minha matriz tem 2 dimensões (0 e 1), nesse caso estou utilizando a 1
            //public int GetLowerBound(dimensão);
            Console.WriteLine("GetLowerBound");
            int menorIndiceVetor=vetor1.GetLowerBound(0);
            int menorIndiceMatriz_D1=matriz.GetLowerBound(1);
            Console.WriteLine("Menor índice do vetor1 {0}", menorIndiceVetor);
            Console.WriteLine("Menor índice da matriz {0}", menorIndiceMatriz_D1);
            Console.WriteLine("----------------------------------------");

            //retorna o maior índice do vetor ou matriz
            //a dimensão irá informar se é uma matriz ou array
            //vetor tem dimenção 0
            //a minha matriz tem 2 dimensões (0 e 1), nesse caso estou utilizando a 1
            //public int GetLowerBound(dimensão);
            Console.WriteLine("GetUpperBound");
            int maiorIndiceVetor=vetor1.GetUpperBound(0);
            int maiorIndiceMatriz_D1=matriz.GetUpperBound(1);
            Console.WriteLine("Maior índice do vetor1 {0}", maiorIndiceVetor);
            Console.WriteLine("Maior índice da matriz {0}", maiorIndiceMatriz_D1);
            Console.WriteLine("----------------------------------------");
            
            ///retorna um valor a partir de um índice
            //o cating é necessário pelo fato do método retornar um object
            //e é object pq posso ter vetor/matriz de outros tipos diferente de int
            //public object GetValue(long indice);
            Console.WriteLine("GetValue");
            int valor0=Convert.ToInt32(vetor1.GetValue(3));
            int valor1=Convert.ToInt32(matriz.GetValue(1,3));
            Console.WriteLine("Valor da posição 3 do vetor1: {0}", valor0);
            Console.WriteLine("Valor da posição 3 da matriz: {0}", valor1);
            Console.WriteLine("----------------------------------------");

            //retorna o índice do valor indicado
            //se meu array tiver 3 numeros 5, retornará o índice do primeiro 5 encontrado
            //public static int IndexOf(array, valor);
            Console.WriteLine("IndexOf");
            int indice1=Array.IndexOf(vetor1,3);
            Console.WriteLine("Índice do primeiro valor 3: {0}", indice1);
            Console.WriteLine("----------------------------------------");

            //retorna o índice do valor indicado
            //se meu array tiver 3 numeros 5, retornará o índice do último 5 encontrado
            //public static int LastIndexOf(array, valor);
            Console.WriteLine("LastIndexOf");
            int indice2=Array.LastIndexOf(vetor1,3);
            Console.WriteLine("Índice do último valor 3: {0}", indice2);
            Console.WriteLine("----------------------------------------");

            //inverte a ordem dos elementos
            //public static void Reverse(array);
            Array.Reverse(vetor1);
            foreach(int n in vetor1){
                Console.WriteLine(n);
            }

            //permite setar um valor em uma determinada posição do nosso vetor
            //(valor que eu quero setar, posição)
            //public void SetValue(object valor, long pos);
            vetor2.SetValue(99,0); //90 na posição 0
            for(int i=0;i<vetor2.Length;i++){
                vetor2.SetValue(0,i);//0 em todas as posições
            }
            Console.WriteLine("Vetor2");
            foreach(int n in vetor2){
                Console.WriteLine(n);
            }

            //ordenar em ordem crescente os elementos do nosso array
            //Para ordem descescente poderia usar um sort+reverse
            //public static void Sort(array);
            Array.Sort(vetor1);
            Array.Sort(vetor2);
            Array.Sort(vetor3);
            Console.WriteLine("Vetor1");
            foreach(int n in vetor1){
                Console.WriteLine(n);
            }
            Console.WriteLine("\nVetor2");
            foreach(int n in vetor2){
                Console.WriteLine(n);
            }
            Console.WriteLine("\nVetor3");
            foreach(int n in vetor3){
                Console.WriteLine(n);
            }
        }
    }
}
