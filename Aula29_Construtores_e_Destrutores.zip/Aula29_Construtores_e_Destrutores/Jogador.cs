using System;

public class Jogador
    {
        public int energia;
        public bool vivo;
        public string nome;


        //CONSTRUTOR
        public Jogador(string nome){
            energia=100;
            vivo=true;
            this.nome = nome;
        }

        //DESTRUIDOR
        ~Jogador(){
            Console.WriteLine("Jogador {0} foi destruído", nome);
        }
    }