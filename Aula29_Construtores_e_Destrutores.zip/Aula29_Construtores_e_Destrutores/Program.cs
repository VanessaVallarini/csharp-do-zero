﻿using System;

namespace Aula29_Construtores_e_Destrutores2
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("JOGADOR 1");
            Jogador j1=new Jogador("Vanessa");
            Console.WriteLine("Energia do jogador 1: {0}\nNome do jogador 1:{1}", j1.energia, j1.nome);

            Console.WriteLine("\nJOGADOR 2");
            Jogador j2=new Jogador("João");
            j2.energia=50;// com o atibuto público eu consigo alterar seu valor
            Console.WriteLine("Energia do jogador 2: {0}\nNome do jogador 2:{1}", j2.energia, j2.nome);
 
            //cada jogador possui um endereço diferente na memória e são independentes

            
            string name;
            Console.Write("\nDigite o nome do jogador 3:");
            name=Console.ReadLine();

            Console.WriteLine("\nJOGADOR 3");
            Jogador j3=new Jogador(name);
            Console.WriteLine("Energia do jogador 3: {0}\nNome do jogador 3:{1}", j3.energia, j3.nome);
        }
    }
}
