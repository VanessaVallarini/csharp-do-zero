﻿using System;

namespace Aula50_Delegates
{
    class Program
    {
        static void Main(string[] args)
        {
            int res;
            Cacl.Operacao d1 = new Cacl.Operacao(Cacl.soma);
            res = d1(10,50);
            Console.WriteLine("Soma: {0}", res);

            d1 = new Cacl.Operacao(Cacl.mult);
            res = d1(10,50);
            Console.WriteLine("Multiplicação: {0}", res);

        }
    }
}
