using System;

public class Cacl{
    //repare que tem a mesma quantidade de entrada de parâmetros
    //que os métodos da classe, podemos usar um params
    public delegate int Operacao(int n1, int n2);
    public static int soma(int n1, int n2){
        return n1+n2;
    }

    public static int mult(int n1, int n2){
        return n1*n2;
    }
}