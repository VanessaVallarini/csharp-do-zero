﻿using System;

namespace Aula44_Struct
{
    class Program
    {
        static void Main(string[] args)
        {
             //FORMA DE CHAMAR 1
            Carro c1 = new Carro("VW","FUSCA", "VERDE");
            c1.info();
            
            //FORMA DE CHAMAR 2
            Carro c2;
            c2.marca="FIAT";
            c2.modelo="UNO";
            c2.cor="BRANCO";
            Console.WriteLine("\nCARRO 2:");
            Console.WriteLine("Marca:..{0}", c2.marca);
            Console.WriteLine("Modelo:.{0}", c2.modelo);
            Console.WriteLine("Cor:....{0}", c2.cor);

            //FORMA DE CHAMAR 3
            Carro c3 = new Carro("TOYOTA","COROLLA", "PRETO");
            Console.WriteLine("\nCARRO 3:");
            Console.WriteLine("Marca:..{0}", c3.marca);
            Console.WriteLine("Modelo:.{0}", c3.modelo);
            Console.WriteLine("Cor:....{0}", c3.cor);
        }
    }
}
