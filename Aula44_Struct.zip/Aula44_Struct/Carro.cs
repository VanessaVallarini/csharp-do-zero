using System;

public struct Carro{
    public string marca;
    public string modelo;
    public string cor;

    public Carro(string marca, string modelo, string cor){
        this.marca=marca;
        this.modelo=modelo;
        this.cor=cor;
    }

    public void info(){
        Console.WriteLine("CARRO 1:");
        Console.WriteLine("Marca:..{0}", marca);
        Console.WriteLine("Modelo:.{0}", modelo);
        Console.WriteLine("Cor:....{0}", cor);
    }

}