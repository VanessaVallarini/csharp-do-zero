﻿using System;

namespace Aula19_FOR
{
    class Program
    {
        static void Main(string[] args)
        {
            //Pra usar uma estrutura de iteração - Loop
            //Sempre que precisarmos repetir uma série um comando ou uma sequência de comandos
            //Posso usar para leitura de arrays, matrizes ou
            //inicialização desses componentes (arrays, matrizes)
            //O For é mais usado quando eu sei a qtd devezes que irei repetir esse comando
            //Estrutura do for:
            //for(inicializador da contagem, expressão lógica, incremento/decremento)

            //INICIALIZADOR
            //int num=0; Posso iniciar a atividade aqui ou dentro do for
            // a diferença é que a mesma é usada apenas dentro do for

            //EXPRESSÃO LÓGICA
            //Enquanto for verdadeira o loop será executado

            //INCREMENTO/DECREMENTO

            int[] num=new int[10];

            for(int i=0;i<num.Length;i++) //num=num+1; num+=1; num++
            {
                num[i]=i;
                Console.WriteLine("Valor de num na pos{0}: {1}", i, num[i]);
            }
        }
    }
}
