﻿using System;
//importando a coleção Dicionário
using System.Collections.Generic;

namespace Aula55_Colecao_Dictionary
{
    class Program
    {
        static void Main(string[] args)
        {
            //int: chave/ string: valor
            Dictionary <int, string> veiculos = new Dictionary<int, string>();

            //Dictionary é uma classe e acima criamos uma instância dessa classe

            veiculos.Add(10, "Carro");
            veiculos.Add(5, "Avião");
            veiculos.Add(0, "Navio");
            veiculos.Add(20, "Moto");
            veiculos.Add(15, "Patinete");

            //propriedades dictionarys
            Console.WriteLine("Tamanho do dicionário:.{0}", veiculos.Count);

            //removendo um elemento com determinada chave
            veiculos.Remove(20);

            //substituindo uma propriedade no dictionarys
            veiculos[0]="Bicicleta";

            //verificando se possui algum elemento com determinada chave
            int chave = 20;
            if(veiculos.ContainsKey(chave)){
                Console.WriteLine("A chave {0} está na coleção!", chave);
            }else{
                Console.WriteLine("A chave {0} não está na coleção!", chave);
            }

            //verificando se possui algum elemento com determinado valor
            string valor = "Bicicleta";
            if(veiculos.ContainsValue(valor)){
                Console.WriteLine("O valor {0} está na coleção!", valor);
            }else{
                Console.WriteLine("O valor {0} não está na coleção!", valor);
            }

            //imprimindo todas as propriedades do dictionarys
            foreach(KeyValuePair<int, string> v in veiculos){
                Console.WriteLine("Chave: {0} | Valor: {1}", v.Key,v.Value); 
                //aqui posso imprimir a chave ou o valor ou ambos
            }

            //imprimindo todas as propriedades do dictionarys B
            Dictionary<int, string>.ValueCollection valores = veiculos.Values;
            foreach(string v in valores){
                Console.WriteLine("Valor: {0}", v); 
                //aqui posso imprimir a chave ou o valor ou ambos
            }

            //propriedades dictionarys
            Console.WriteLine("Limpando o dicionário.");
            veiculos.Clear();
            Console.WriteLine("Tamanho do dicionário:.{0}", veiculos.Count);
            
        }
    }
}
