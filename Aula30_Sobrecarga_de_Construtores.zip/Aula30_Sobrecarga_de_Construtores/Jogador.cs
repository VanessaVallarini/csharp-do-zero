using System;

public class Jogador
{
    public int energia;
    public bool vivo;
    public string nome;


    //CONSTRUTOR
    public Jogador()
    {
        energia = 100;
        vivo = true;
        this.nome = "Jogador";
    }
    public Jogador(string nome)
    {
        energia = 100;
        vivo = true;
        this.nome = nome;
    }
    public Jogador(string nome, int energia)
    {
        this.energia = energia;
        vivo = true;
        this.nome = nome;
    }
    public Jogador(string nome, int energia, bool vivo)
    {
        this.energia = energia;
        this.vivo = vivo;
        this.nome = nome;
    }

    public void info()
    {
        Console.WriteLine("Nome Jogador: {0}", nome);
        Console.WriteLine("Energia Jogador: {0}", energia);
        Console.WriteLine("Estado Jogador: {0}\n", vivo);
    }

    //DESTRUIDOR
    ~Jogador()
    {
    }
}