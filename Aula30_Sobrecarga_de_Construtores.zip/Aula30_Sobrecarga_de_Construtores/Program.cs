﻿using System;

namespace Aula30_Sobrecarga_de_Construtores
{
    class Program
    {
        static void Main(string[] args)
        {
            Jogador j1 = new Jogador();
            Jogador j2 = new Jogador("Bruno");
            Jogador j3 = new Jogador("Théo", 100);
            Jogador j4 = new Jogador("Ben", 0, false);

            j1.info();
            j2.info();
            j3.info();
            j4.info();
        }
    }
}
